#ifndef SERVOCTRL_H_
#define SERVOCTRL_H_

//#include "sw/solutions/instaspin_motion/src/main.h"
#include "sw/modules/hal/boards/TAPAS_V1.0/f28x/f2806x/src/hal_obj.h"

// HINT :
// GPIO19 is used as an input for receiving the servo-signal;
// please keep in mind to properly configure it as an eCAP1-Input
// e.g. in the file "hal.c" at the function
// void HAL_setupGpios(HAL_Handle handle);
// as follows:
//   GPIO_setMode(obj->gpioHandle,GPIO_Number_19,GPIO_19_Mode_ECAP1);

#define T_SYS_s    (1.0 / (USER_SYSTEM_FREQ_MHz*1000000.0))
#define T_PULSE_s  0.0020
#define T_OFFSET_s 0.00093

#define T_EXPECTED_s  (T_PULSE_s / T_SYS_s)
#define T_OFFSET_EXPECTED_s  (T_OFFSET_s / T_SYS_s)


//! \brief     Initializes and sets up modules for reading in a servo-signal
//! \param[in] halHandle    a handle to the Hardware-Abstraction-Layer used
void servoCTRL_setup(HAL_Handle halHandle);

//! \brief     get the demanded power out of the servo-signal
// (the term "pulse duration" here means the on-time of the pulse)
// a pulse duration of 1.0ms is transformed to   0.0%
// a pulse duration of 1.5ms is transformed to  50.0%
// a pulse duration of 2.0ms is transformed to 100.0%
//! \return    returns a percetage value for the power demanded by the servo-signal
// HINT: the user has to take care, if the returned value is valid!
float servoCTRL_getSetpointPower();

#endif /* SERVOCTRL_H_ */
