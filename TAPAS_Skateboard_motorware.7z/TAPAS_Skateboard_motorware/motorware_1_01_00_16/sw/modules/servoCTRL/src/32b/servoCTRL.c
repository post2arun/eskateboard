#include "servoCTRL.h"


CAP_Handle eCAP1handle = NULL;

void servoCTRL_setup(HAL_Handle halHandle){

    CLK_enableEcap1Clock(halHandle->clkHandle);

    eCAP1handle = CAP_init((void *)CAP1_BASE_ADDR, sizeof(CAP_Obj));

    // Disable all capture interrupts
    CAP_disableInt(eCAP1handle, CAP_Int_Type_All);

    // Clear all CAP interrupt flags
    //    -> not available in the driver but also not necessary as we don't use interrupts here

    // Disable CAP1-CAP4 register loads
    CAP_disableCaptureLoad(eCAP1handle);

    // Make sure the counter is stopped
    CAP_disableTimestampCounter(eCAP1handle);

    // Continous-Mode
    CAP_setCapContinuous(eCAP1handle);

    // Rising edge for CAP1POL
    CAP_setCapEvtPolarity(eCAP1handle, CAP_Event_1, CAP_Polarity_Rising);

    // Falling edge for CAP2POL
    CAP_setCapEvtPolarity(eCAP1handle, CAP_Event_2, CAP_Polarity_Falling);

    // Difference operation CTRRST1
    CAP_setCapEvtReset(eCAP1handle, CAP_Event_1, CAP_Reset_Enable);

    // Difference operation CTRRST2
    CAP_setCapEvtReset(eCAP1handle, CAP_Event_2, CAP_Reset_Enable);

    // Enable Sync In
    CAP_enableSyncIn(eCAP1handle);

    // Pass through
    CAP_setSyncOut(eCAP1handle, CAP_SyncOut_SyncIn);

    // Enable Capture Units
    CAP_enableCaptureLoad(eCAP1handle);

    // Start Counter
    CAP_enableTimestampCounter(eCAP1handle);

    // Enable CAP1-CAP4 register loads
    CAP_enableCaptureLoad(eCAP1handle);

}

// returns a percentage value for the power demanded by the servo-signal:
// (the term "pulse duration" here means the on-time of the pulse)
// a pulse duration of 1.0ms is transformed to   0.0%
// a pulse duration of 1.5ms is transformed to  50.0%
// a pulse duration of 2.0ms is transformed to 100.0%
float servoCTRL_getSetpointPower(){

    if(eCAP1handle == NULL){
        return 0.0;
    }else{
        return (
                (float)((eCAP1handle->CAP2 - (uint32_t)T_OFFSET_EXPECTED_s)) /
                (float)((uint32_t) T_EXPECTED_s - (uint32_t)T_OFFSET_EXPECTED_s) )
                *100.0;
    }
}
