#ifndef SPICTRL_H_
#define SPICTRL_H_

#include <hal_obj.h>

#define CACTUS_NOT_OK 0
#define CACTUS_NO_RECEIVE 1
#define CACTUS_NEW_DATA_OK 2


typedef struct _tEspRx
{
   uint16_t flags;
   uint16_t i_Motor_numPolePairs;
   float f_Motor_ratedCurrent;
   float f_Motor_RoverLestFrequencyHz;
   float f_Motor_fluxEstFrequency;
   float f_CTRL_setpoint_speed;
   float f_CTRL_setpoint_accel;
   float f_resFloat0;
   float f_resFloat1;
   float f_resFloat2;
   float f_resFloat3;
   float f_resFloat4;
   float f_resFloat5;
   float f_resFloat6;
   float f_resFloat7;
   float f_resFloat8;
   float f_resFloat9;
   float f_resFloat10;
   uint16_t u_STATUS_DOUT;
   uint16_t reserved2;
   uint16_t reserved3;
   uint16_t CRC;
} tEspRx;

typedef struct _tEspTx
{
    uint16_t flags;
    uint16_t u_STATUS_statusErr;
    float f_STATUS_UdcBus;
    float f_STATUS_IdcBus;
    float f_STATUS_boardTemp;
    float f_STATUS_currSpeed;
    uint16_t u_CTRL_state;
    uint16_t u_EST_state;
    float f_IDENT_motorRs;
    float f_IDENT_motorRr;
    float f_IDENT_motorLsd;
    float f_IDENT_motorLsq;
    float f_EST_ratedFlux;
    float f_ANALOG_IN_0;
    float f_ANALOG_IN_1;
    float f_ANALOG_IN_2;
    float f_ANALOG_IN_3;
    float f_ANALOG_IN_4;
    float f_ANALOG_IN_5;
    uint16_t u_STATUS_DIN;
    uint16_t spiStatus;
    uint16_t reserved2;
    uint16_t CRC;
} tEspTx;

#define DATA_SIZE (sizeof(struct _tEspRx) / sizeof(uint16_t))

#define NUM_BUFFER 3  // Not to be modified
#define BUFFER_SIZE (DATA_SIZE*NUM_BUFFER)  // Not to be modified

#define REQUIRED_SUCCESSFUL_ESP_TRANSACTIONS 5


extern uint16_t rx_buffer[BUFFER_SIZE];
extern uint16_t tx_buffer[BUFFER_SIZE];


void GenerateCrcTable(void);
uint16_t CalcCrc(uint16_t *data, uint16_t len_words);
uint16_t GetNewSetpoints(DMA_Handle DMAhandle, tEspRx *my_esp_rx, tEspTx *my_esp_tx);

#endif /* SPICTRL_H_ */
