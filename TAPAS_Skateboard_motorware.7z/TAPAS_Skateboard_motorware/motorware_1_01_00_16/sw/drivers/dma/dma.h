#ifndef DMA_H_
#define DMA_H_


// **************************************************************************
// the includes

#include "sw/modules/types/src/types.h"

#include "sw/drivers/cpu/src/32b/f28x/f2806x/cpu.h"

#include "sw/drivers/pie/src/32b/f28x/f2806x/pie.h"

#ifdef __cplusplus
extern "C" {
#endif

// **************************************************************************
// the defines

//! \brief Defines the base address of the (mcBSP) registers
#define  DMA_BASE_ADDR        (0x00001000)

// MODE
//==========================
// PERINTSEL bits
#define DMA_SEQ1INT 	1
#define DMA_SEQ2INT 	2
#define DMA_XINT1   	3
#define DMA_XINT2   	4
#define DMA_XINT3   	5
#define DMA_USB0EP1RX	7
#define DMA_USB0EP1TX	8
#define DMA_USB0EP2RX	9
#define DMA_USB0EP2TX	10
#define DMA_TINT0   	11
#define DMA_TINT1   	12
#define DMA_TINT2   	13
#define DMA_MXEVTA  	14
#define DMA_MREVTA  	15
#define DMA_EPWM2A  	18
#define DMA_EPWM2B  	19
#define DMA_EPWM3A  	20
#define DMA_EPWM3B  	21
#define DMA_EPWM4A  	22
#define DMA_EPWM4B  	23
#define DMA_EPWM5A  	24
#define DMA_EPWM5B  	25
#define DMA_EPWM6A  	26
#define DMA_EPWM6B  	27
#define DMA_EPWM7A  	28
#define DMA_EPWM7B  	29
#define DMA_USB0EP3RX	30
#define DMA_USB0EP3TX	31
// OVERINTE bit
#define OVRFLOW_DISABLE 0x0
#define OVEFLOW_ENABLE  0x1
// PERINTE bit
#define PERINT_DISABLE  0x0
#define PERINT_ENABLE   0x1
// CHINTMODE bits
#define CHINT_BEGIN     0x0
#define CHINT_END       0x1
// ONESHOT bits
#define ONESHOT_DISABLE 0x0
#define ONESHOT_ENABLE  0x1
// CONTINOUS bit
#define CONT_DISABLE    0x0
#define CONT_ENABLE     0x1
// SYNCE bit
#define SYNC_DISABLE    0x0
#define SYNC_ENABLE     0x1
// SYNCSEL bit
#define SYNC_SRC        0x0
#define SYNC_DST        0x1
// DATASIZE bit
#define SIXTEEN_BIT     0x0
#define THIRTYTWO_BIT   0x1
// CHINTE bit
#define CHINT_DISABLE   0x0
#define CHINT_ENABLE    0x1

//---------------------------------------------------------------------------
// DMA Individual Register Bit Definitions:
//MODE_BITS
// 4:0	Peripheral Interrupt and Sync Select
#define DMA_MODE_PERINTSEL_BITS		0
// 6:5	Reserved

/// 7	Overflow Interrupt Enable
#define DMA_MODE_OVRINTE_BIT		7
// 8	Peripheral Interrupt Enable
#define DMA_MODE_PERINTE_BIT		8
// 9	Channel Interrupt Mode
#define DMA_MODE_CHINTMODE_BIT		9
// 10	One Shot Mode Bit
#define DMA_MODE_ONESHOT_BIT		10
// 11	Continuous Mode Bit
#define DMA_MODE_CONTINUOUS_BIT		11
// 13:12	Reserved

// 14	Data Size Mode Bit
#define DMA_MODE_DATASIZE_BIT		14
// 15	Channel Interrupt Enable Bit
#define DMA_MODE_CHINTE_BIT			15

//CONTROL_BITS
// 0	Run Bit
#define DMA_CONTROL_RUN_BIT			0
// 1	Halt Bit
#define DMA_CONTROL_HALT_BIT		1
// 2	Soft Reset Bit
#define DMA_CONTROL_SOFTRESET_BIT	2
// 3	Interrupt Force Bit
#define DMA_CONTROL_PERINTFRC_BIT 	3
// 4	Interrupt Clear Bit
#define DMA_CONTROL_PERINTCLR_BIT	4
// 6:5	Reserved

// 7	Error Clear Bit
#define DMA_CONTROL_ERRCLR_BIT		7
// 8	Interrupt Flag Bit
#define DMA_CONTROL_PERINTFLG_BIT	8
// 9	Sync Flag Bit
#define DMA_CONTROL_SYNCFLG_BIT		9
// 10	Sync Error Flag Bit
#define DMA_CONTROL_SYNCERR_BIT		10
// 11	Transfer Status Bit
#define DMA_CONTROL_TRANSFERSTS_BIT	11
// 12	Burst Status Bit
#define DMA_CONTROL_BURSTSTS_BIT	12
// 13	Run Status Bit
#define DMA_CONTROL_RUNSTS_BIT		13
// 14	Overflow Flag Bit
#define DMA_CONTROL_OVRFLG_BIT		14
// 15	Reserved

//DMACTRL_BITS
// 0	Hard Reset Bit
#define DMA_DMACTRL_HARDRESET_BIT		0
// 1	Priority Reset Bit
#define DMA_DMACTRL_PRIORITYRESET_BIT	1
// 15:2	Reserved

//DEBUGCTRL_BITS
// 14:0	Reserved

// 15	Debug Mode Bit
#define DMA_DEBUGCTRL_FREE_BIT			15

//PRIORITYCTRL1_BITS
// 0	Ch1 Priority Bit
#define DMA_PRIORITYCTRL1_CH1PRIORITY_BIT 0
// 15:1	Reserved

//PRIORITYSTAT_BITS
// 2:0	Active Channel Status Bits
#define DMA_PRIORITYSTAT_ACTIVESTS_BIT 			0
// 3	Reserved

// 6:4	Active Channel Status Shadow Bits
#define DMA_PRIORITYSTAT_ACTIVESTS_SHADOW_BIT 	4
// 15:7	Reserved

struct CH_REGS {
	uint16_t 	MODE;					// Mode Register
	uint16_t 	CONTROL;				// Control Register
	uint16_t 	BURST_SIZE;				// Burst Size Register
	uint16_t 	BURST_COUNT;			// Burst Count Register
	int16_t		SRC_BURST_STEP;			// Source Burst Step Register
	int16_t		DST_BURST_STEP;			// Destination Burst Step Register
	uint16_t	TRANSFER_SIZE;			// Transfer Size Register
	uint16_t	TRANSFER_COUNT;			// Transfer Count Register
	int16_t		SRC_TRANSFER_STEP;		// Source Transfer Step Register
	int16_t		DST_TRANSFER_STEP;		// Destination Transfer Step Register
	uint16_t	SRC_WRAP_SIZE;			// Source Wrap Size Register
	uint16_t	SRC_WRAP_COUNT;			// Source Wrap Count Register
	int16_t		SRC_WRAP_STEP;			// Source Wrap Step Register
	uint16_t	DST_WRAP_SIZE;			// Destination Wrap Size Register
	uint16_t	DST_WRAP_COUNT;			// Destination Wrap Count Register
	int16_t		DST_WRAP_STEP;			// Destination Wrap Step Register
	uint32_t	SRC_BEG_ADDR_SHADOW;	// Source Begin Address Shadow Register
	uint32_t	SRC_ADDR_SHADOW;		// Source Address Shadow Register
	uint32_t	SRC_BEG_ADDR_ACTIVE;	// Source Begin Address Active Register
	uint32_t	SRC_ADDR_ACTIVE;		// Source Address Active Register
	uint32_t	DST_BEG_ADDR_SHADOW;	// Destination Begin Address Shadow Register
	uint32_t	DST_ADDR_SHADOW;		// Destination Address Shadow Register
	uint32_t	DST_BEG_ADDR_ACTIVE;	// Destination Begin Address Active Register
	uint32_t	DST_ADDR_ACTIVE;		// Destination Address Active Register
};

//! \brief Defines the Direct Memory Access (DMA) object
typedef struct _DMA_Obj_ {
	volatile uint16_t 			DMACTRL;		// DMA Control Register
	volatile uint16_t 			DEBUGCTRL;		// Debug Control Register
	volatile uint16_t 			REVISION;		// /*Reserved*/ Revision-Bits ...
	volatile uint16_t			rsvd1;			// Reserved
	volatile uint16_t 			PRIORITYCTRL1;	// Priority Control 1 Register
	volatile uint16_t			rsvd2;			// Reserved
	volatile uint16_t 			PRIORITYSTAT;	// Priority Status Register
	volatile uint16_t			rsvd3[25];		// Reserved
	volatile struct CH_REGS		CH1;            // DMA Channel 1 Registers
	volatile struct CH_REGS		CH2;            // DMA Channel 2 Registers
	volatile struct CH_REGS		CH3;            // DMA Channel 3 Registers
	volatile struct CH_REGS		CH4;            // DMA Channel 4 Registers
	volatile struct CH_REGS		CH5;            // DMA Channel 5 Registers
	volatile struct CH_REGS		CH6;            // DMA Channel 6 Registers
} DMA_Obj;

//! \brief Defines the general purpose I/O (GPIO) handle
typedef struct _DMA_Obj_ *DMA_Handle;


enum DMA_CHANNEL{
	DMA_CH1, DMA_CH2, DMA_CH3, DMA_CH4, DMA_CH5, DMA_CH6
};

extern DMA_Handle DMA_init(void *pMemory,const size_t numBytes);

extern void DMA_run(DMA_Handle DMAhandle, uint16_t DMAChannel);

extern void DMA_stop(DMA_Handle DMAhandle, uint16_t DMAChannel);

extern void DMA_hardReset(DMA_Handle DMAhandle);

extern void DMA_priorityReset(DMA_Handle DMAhandle);

extern void DMA_enableFREE(DMA_Handle DMAhandle);

extern void DMA_disableFREE(DMA_Handle DMAhandle);

extern void DMA_CH1normalMode(DMA_Handle DMAhandle);

extern void DMA_CH1highPriorityMode(DMA_Handle DMAhandle);


extern void DMA_AddrConfig(DMA_Handle DMAhandle, uint16_t DMAChannel,
					volatile uint16_t *DMA_Dest,volatile uint16_t *DMA_Source);

extern void DMA_BurstConfig(DMA_Handle DMAhandle, uint16_t DMAChannel,
						uint16_t bsize, int16_t srcbstep, int16_t desbstep);

extern void DMA_TransferConfig(DMA_Handle DMAhandle, uint16_t DMAChannel,
							uint16_t tsize, int16_t srctstep, int16_t deststep);

extern void DMA_WrapConfig(DMA_Handle DMAhandle, uint16_t DMAChannel,
						uint16_t srcwsize, int16_t srcwstep, uint16_t deswsize, int16_t deswstep);

extern void DMA_ModeConfig(DMA_Handle DMAhandle, PIE_Handle PIEhandle, uint16_t DMAChannel,
						uint16_t persel, uint16_t perinte, uint16_t oneshot, uint16_t cont,
						uint16_t synce, uint16_t syncsel, uint16_t ovrinte,
						uint16_t datasize, uint16_t chintmode, uint16_t chinte);

extern void DMA_enableChannelInterrupt(DMA_Handle DMAhandle, uint16_t DMAChannel);

extern void DMA_disableChannelInterrupt(DMA_Handle DMAhandle, uint16_t DMAChannel);

extern void DMA_SoftReset(DMA_Handle DMAhandle, uint16_t DMAChannel);

#ifdef __cplusplus
}
#endif // extern "C"

#endif /* DMA_H_ */
