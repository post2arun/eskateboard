#ifndef SPIMCBSP_H_
#define SPIMCBSP_H_

// **************************************************************************
// the includes

#include "sw/modules/types/src/types.h"

#include "sw/drivers/cpu/src/32b/f28x/f2806x/cpu.h"

#ifdef __cplusplus
extern "C" {
#endif

// **************************************************************************
// the defines

//! \brief Defines the base address of the (mcBSP) registers
//!
#define MCBSPA_BASE_ADDR        (0x00005000)
#define MCBSPB_BASE_ADDR		(0x00005040)

//---------------------------------------------------------------------------

/****	Data Registers, Receive, Transmit	****/
// DRR2_BITS (McBSP Data Receive Register 2)
// 15:0 	High part of receive data (for 20-, 24- or 32-bit data)
#define MCBSP_DDR2_BITS  			0

// DRR1_BITS (McBSP Data Receive Register 1)
// 15:0 Receive data (for 8-, 12-, or 16-bit data) or low part of receive data (for 20-, 24- or 32-bit data)
#define MCBSP_DDR1_BITS  			0

// DXR2_BITS (McBSP Data Transmit Register 2)
// 15:0 High part of transmit data (for 20-, 24- or 32-bit data)
#define MCBSP_DXR2_BITS  			0

// DXR1_BITS (McBSP Data Transmit Register 1)
// 15:0 Transmit data (for 8-, 12-, or 16-bit data) or low part of receive data (for 20-, 24- or 32-bit data)
#define MCBSP_DXR1_BITS  			0

/****	McBSP Control Registers	****/
// SPCR2_BITS (McBSP Serial Port Control Register 2)
// 0 	Transmitter reset Bit
#define MCBSP_SPCR2_XRST_BIT		0
// 1	Transmitter ready bit
#define MCBSP_SPCR2_XRDY_BIT		1
// 2	Transmitter empty bit
#define MCBSP_SPCR2_XEMPTY_BIT		2
// 3	Transmit frame-synchronization error bit
#define MCBSP_SPCR2_XSYNCERR_BITS	3
// 5:4 	Transmit interrupt mode bits
#define MCBSP_SPCR2_XINTM_BIT		4
// 6	Sample rate generator reset bit
#define MCBSP_SPCR2_GRST_BIT		6
// 7	Frame-synchronization logic reset bit
#define MCBSP_SPCR2_FRST_BIT		7
// 8	Soft stop bit
#define MCBSP_SPCR2_SOFT_BIT		8
// 9 	Free run bit
#define MCBSP_SPCR2_FREE_BIT		9

// SPCR1_BITS (McBSP Serial Port Control Register 1)
// 0 	Receiver reset bit
#define MCBSP_SPCR1_RRST_BIT  		0
// 1	Receiver ready bit
#define MCBSP_SPCR1_RRDY_BIT		1
// 2	Receiver full bit.
#define MCBSP_SPCR1_RFULL_BIT		2
// 3	Receive frame-sync error bit
#define MCBSP_SPCR1_RSYNCERR_BIT	3
// 5:4	Receive interrupt mode bits
#define MCBSP_SPCR1_RINTM_BITS		4
// 7	DX delay enabler mode bit
#define MCBSP_SPCR1_DXENA_BIT		7
// 12:11 Clock stop mode bits
#define MCBSP_SPCR1_CLKSTP_BITS 	11
// 14:13 Receive sign-extension and justification mode bits
#define MCBSP_SPCR1_RJUST_BITS 		13
// 15	Digital loopback mode bit
#define MCBSP_SPCR1_DLB_BIT			15

// RCR2_BITS  (McBSP Receive Control Register 2)
// 1:0 	Receive data delay bits
#define MCBSP_RCR2_RDATDLY_BITS  	0
// 2	Receive frame-synchronization ignore bit
#define MCBSP_RCR2_RFIG_BIT 		2
// 4:3	Receive companding mode bits
#define MCBSP_RCR2_RCOMPAND_BITS 	3
// 7:5	Receive word length 2
#define MCBSP_RCR2_RWDLEN2_BITS		5
// 14:8 Receive frame length 2
#define MCBSP_RCR2_RFRLEN2_BITS 	8
// 15	Receive phase number bit
#define MCBSP_RCR2_RPHASE_BIT		15

// RCR1_BITS  (McBSP Receive Control Register 1)
// 7:5 	Receive word length 1
#define MCBSP_RCR1_RWDLEN1_BITS  	5
// 14:8 Receive frame length 1 (1 to 128 words)
#define MCBSP_RCR1_RFRLEN1_BITS		8

// XCR2_BITS  (McBSP Transmit Control Register 2)
// 1:0 	Transmit data delay bits
#define MCBSP_XCR2_XDATDLY_BITS  	0
// 2 	Transmit frame-synchronization ignore bit
#define MCBSP_XCR2_XFIG 			2
// 4:3 	Transmit companding mode bits
#define MCBSP_XCR2_XCOMPAND 		3
// 7:5 	Transmit word length 2
#define MCBSP_XCR2_XWDLEN2 			5
// 14:8 Transmit frame length 2 (1 to 128 words)
#define MCBSP_XCR2_XFRLEN2 			8
// 15 	Transmit phase number bit
#define MCBSP_XCR2_XPHASE 			15

// XCR1_BITS  (McBSP Transmit Control Register 1)
// 7:5 	Transmit word length 1
#define MCBSP_XCR1_XWDLEN1_BITS  	5
// 14:8 Transmit frame length 1 (1 to 128 words)
#define MCBSP_XCR1_XFRLEN1_BITS		8

// SRGR2_BITS (McBSP Sample Rate Generator Register 2)
// 11:0 Frame-synchronization period bits for FSG
#define MCBSP_SRGR2_FPER_BITS  		0
// 12 	Sample rate generator transmit frame-synchronization mode bit
#define MCBSP_SRGR2_FSGM_BIT 		12
// 13 	Sample rate generator input clock mode bit
#define MCBSP_SRGR2_CLKSM_BIT 		13
// 15 	Clock synchronization mode bit for CLKG
#define MCBSP_SRGR2_GSYNC_BIT 		15

// SRGR1_BITS (McBSP Sample Rate Generator Register 1)
// 7:0 	Divide-down value for CLKG
#define MCBSP_SRGR1_CLKGDV_BITS  	0
// 15:8 Frame-synchronization pulse width bits for FSG
#define MCBSP_SRGR1_FWID_BITS 		8

/****	Multichannel Control Registers	****/
// MCR2_BITS   (McBSP Multichannel Register 2)
// 1:0 	Transmit multichannel selection mode bits
#define MCBSP_MCR2_XMCM_BITS  		0
// 4:2 	Transmit current block indicator
#define MCBSP_MCR2_XCBLK_BITS 		2
// 6:5 	Transmit partition A block bits
#define MCBSP_MCR2_XPABLK_BITS 		5
// 8:7 	Transmit partition B block bits
#define MCBSP_MCR2_XPBBLK_BITS 		7
// 9 	Transmit multichannel partition mode bit
#define MCBSP_MCR2_XMCME_BIT 		9

// MCR1_BITS   (McBSP Multichannel Register 1)
// 0 	Receive multichannel selection mode bit
#define MCBSP_MCR1_RMCM_BIT		 	0
// 4:2 	Receive current block indicator
#define MCBSP_MCR1_RCBLK_BITS 		2
// 6:5 	Receive partition A block bits
#define MCBSP_MCR1_RPABLK_BITS		5
// 8:7 	Receive partition B block bits
#define MCBSP_MCR1_RPBBLK_BITS 		7
// 9 	Receive multichannel partition mode bit
#define MCBSP_MCR1_RMCME_BIT 		9

// the RCERA und RCERB - Bits were moved downwards, because
// RCERA to RCERH are internally of the same structure;
// the same is true for the XCERA - XCERH - Bits

// PCR_BITS    (McBSP Pin Control Register)
// 0 	Receive clock polarity bit
#define MCBSP_PCR_CLKRP_BIT 		0
// 1 	Transmit clock polarity bit
#define MCBSP_PCR_CLKXP_BIT 		1
// 2 	Receive frame-synchronization polarity bit
#define MCBSP_PCR_FSRP_BIT 			2
// 3 	Transmit frame-synchronization polarity bit
#define MCBSP_PCR_FSXP_BIT 			3
// 7 	Sample rate generator input clock mode bit
#define MCBSP_PCR_SCLKME_BIT		7
// 8 	Receive clock mode bit
#define MCBSP_PCR_CLKRM_BIT 		8
// 9 	Transmit clock mode bit
#define MCBSP_PCR_CLKXM_BIT 		9
// 10 	Receive frame-synchronization mode bit
#define MCBSP_PCR_FSRM_BIT 			10
// 11 	Transmit frame-synchronization mode bit
#define MCBSP_PCR_FSXM_BIT 			11

// RCERA_BITS  (McBSP Receive Channel Enable Register Partition A)
// 	0 	Receive channel enable bit
#define MCBSP_RCERA_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERA_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERA_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERA_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERA_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERA_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERA_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERA_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERA_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERA_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERA_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERA_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERA_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERA_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERA_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERA_RCE15_BIT 	 	15


// RCERB_BITS  (McBSP Receive Channel Enable Register Partition B)
// 	0 	Receive channel enable bit
#define MCBSP_RCERB_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERB_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERB_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERB_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERB_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERB_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERB_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERB_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERB_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERB_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERB_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERB_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERB_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERB_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERB_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERB_RCE15_BIT 	 	15

// RCERC_BITS  (McBSP Receive Channel Enable Register Partition C)
// 	0 	Receive channel enable bit
#define MCBSP_RCERC_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERC_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERC_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERC_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERC_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERC_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERC_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERC_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERC_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERC_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERC_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERC_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERC_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERC_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERC_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERC_RCE15_BIT 	 	15

// RCERD_BITS  (McBSP Receive Channel Enable Register Partition D)
// 	0 	Receive channel enable bit
#define MCBSP_RCERD_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERD_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERD_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERD_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERD_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERD_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERD_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERD_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERD_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERD_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERD_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERD_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERD_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERD_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERD_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERD_RCE15_BIT 	 	15

// RCERE_BITS  (McBSP Receive Channel Enable Register Partition E)
// 	0 	Receive channel enable bit
#define MCBSP_RCERE_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERE_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERE_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERE_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERE_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERE_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERE_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERE_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERE_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERE_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERE_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERE_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERE_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERE_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERE_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERE_RCE15_BIT 	 	15

// RCERF_BITS  (McBSP Receive Channel Enable Register Partition F)
// 	0 	Receive channel enable bit
#define MCBSP_RCERF_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERF_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERF_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERF_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERF_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERF_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERF_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERF_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERF_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERF_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERF_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERF_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERF_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERF_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERF_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERF_RCE15_BIT 	 	15

// RCERG_BITS  (McBSP Receive Channel Enable Register Partition G)
// 	0 	Receive channel enable bit
#define MCBSP_RCERG_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERG_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERG_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERG_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERG_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERG_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERG_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERG_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERG_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERG_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERG_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERG_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERG_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERG_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERG_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERG_RCE15_BIT 	 	15

// RCERH_BITS  (McBSP Receive Channel Enable Register Partition H)
// 	0 	Receive channel enable bit
#define MCBSP_RCERH_RCE0_BIT 	 	0
// 	1 	Receive channel enable bit
#define MCBSP_RCERH_RCE1_BIT 	 	1
// 	2 	Receive channel enable bit
#define MCBSP_RCERH_RCE2_BIT 	 	2
// 	3 	Receive channel enable bit
#define MCBSP_RCERH_RCE3_BIT 	 	3
// 	4 	Receive channel enable bit
#define MCBSP_RCERH_RCE4_BIT 	 	4
// 	5 	Receive channel enable bit
#define MCBSP_RCERH_RCE5_BIT 	 	5
// 	6 	Receive channel enable bit
#define MCBSP_RCERH_RCE6_BIT 	 	6
// 	7 	Receive channel enable bit
#define MCBSP_RCERH_RCE7_BIT 	 	7
// 	8 	Receive channel enable bit
#define MCBSP_RCERH_RCE8_BIT 	 	8
// 	9 	Receive channel enable bit
#define MCBSP_RCERH_RCE9_BIT 	 	9
// 	10 	Receive channel enable bit
#define MCBSP_RCERH_RCE10_BIT 	 	10
// 	11 	Receive channel enable bit
#define MCBSP_RCERH_RCE11_BIT 	 	11
// 	12 	Receive channel enable bit
#define MCBSP_RCERH_RCE12_BIT 	 	12
// 	13 	Receive channel enable bit
#define MCBSP_RCERH_RCE13_BIT 	 	13
// 	14 	Receive channel enable bit
#define MCBSP_RCERH_RCE14_BIT 	 	14
// 	15 	Receive channel enable bit
#define MCBSP_RCERH_RCE15_BIT 	 	15

// XCERA_BITS  (McBSP Transmit Channel Enable Register Partition A)
// 0	Transmit channel enable bit
#define MCBSP_XCERA_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERA_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERA_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERA_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERA_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERA_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERA_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERA_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERA_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERA_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERA_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERA_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERA_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERA_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERA_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERA_XCE15_BIT		15

// XCERB_BITS  (McBSP Transmit Channel Enable Register Partition B)
// 0	Transmit channel enable bit
#define MCBSP_XCERB_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERB_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERB_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERB_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERB_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERB_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERB_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERB_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERB_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERB_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERB_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERB_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERB_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERB_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERB_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERB_XCE15_BIT		15

// XCERC_BITS  (McBSP Transmit Channel Enable Register Partition C)
// 0	Transmit channel enable bit
#define MCBSP_XCERC_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERC_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERC_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERC_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERC_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERC_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERC_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERC_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERC_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERC_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERC_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERC_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERC_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERC_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERC_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERC_XCE15_BIT		15

// XCERD_BITS  (McBSP Transmit Channel Enable Register Partition D)
// 0	Transmit channel enable bit
#define MCBSP_XCERD_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERD_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERD_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERD_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERD_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERD_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERD_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERD_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERD_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERD_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERD_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERD_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERD_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERD_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERD_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERD_XCE15_BIT		15

// XCERE_BITS  (McBSP Transmit Channel Enable Register Partition E)
// 0	Transmit channel enable bit
#define MCBSP_XCERE_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERE_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERE_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERE_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERE_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERE_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERE_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERE_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERE_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERE_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERE_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERE_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERE_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERE_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERE_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERE_XCE15_BIT		15

// XCERF_BITS  (McBSP Transmit Channel Enable Register Partition F)
// 0	Transmit channel enable bit
#define MCBSP_XCERF_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERF_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERF_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERF_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERF_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERF_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERF_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERF_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERF_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERF_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERF_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERF_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERF_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERF_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERF_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERF_XCE15_BIT		15

// XCERG_BITS  (McBSP Transmit Channel Enable Register Partition G)
// 0	Transmit channel enable bit
#define MCBSP_XCERG_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERG_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERG_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERG_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERG_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERG_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERG_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERG_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERG_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERG_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERG_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERG_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERG_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERG_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERG_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERG_XCE15_BIT		15

// XCERH_BITS  (McBSP Transmit Channel Enable Register Partition H)
// 0	Transmit channel enable bit
#define MCBSP_XCERH_XCE0_BIT		0
// 1	Transmit channel enable bit
#define MCBSP_XCERH_XCE1_BIT		1
// 2	Transmit channel enable bit
#define MCBSP_XCERH_XCE2_BIT		2
// 3	Transmit channel enable bit
#define MCBSP_XCERH_XCE3_BIT		3
// 4	Transmit channel enable bit
#define MCBSP_XCERH_XCE4_BIT		4
// 5	Transmit channel enable bit
#define MCBSP_XCERH_XCE5_BIT		5
// 6	Transmit channel enable bit
#define MCBSP_XCERH_XCE6_BIT		6
// 7	Transmit channel enable bit
#define MCBSP_XCERH_XCE7_BIT		7
// 8	Transmit channel enable bit
#define MCBSP_XCERH_XCE8_BIT		8
// 9	Transmit channel enable bit
#define MCBSP_XCERH_XCE9_BIT		9
// 10	Transmit channel enable bit
#define MCBSP_XCERH_XCE10_BIT		10
// 11	Transmit channel enable bit
#define MCBSP_XCERH_XCE11_BIT		11
// 12	Transmit channel enable bit
#define MCBSP_XCERH_XCE12_BIT		12
// 13	Transmit channel enable bit
#define MCBSP_XCERH_XCE13_BIT		13
// 14	Transmit channel enable bit
#define MCBSP_XCERH_XCE14_BIT		14
// 15	Transmit channel enable bit
#define MCBSP_XCERH_XCE15_BIT		15

// MFFINT_BITS (McBSP Interrupt Enable Register)
// 0 	Enable for transmit Interrupt
#define MCBSP_MFFINT_XINT__ENA_BIT 	0
// 2 	Enable for Receive Interrupt
#define MCBSP_MFFINTRINT__ENA_BIT 	2

//! \brief Defines the Multichannel Buffered Serial Port (McBSP) object
typedef struct _MCBSP_Obj_ {
	volatile uint16_t DRR2;		// Data receive register bits 31-16
	volatile uint16_t DRR1;		// Data receive register bits 15-0
	volatile uint16_t DXR2;		// Data transmit register bits 31-16
	volatile uint16_t DXR1;		// Data transmit register bits 15-0
	volatile uint16_t SPCR2;	// Control register 2
	volatile uint16_t SPCR1;	// Control register 1
	volatile uint16_t RCR2;		// Receive Control register 2
	volatile uint16_t RCR1;		// Receive Control register 1
	volatile uint16_t XCR2;		// Transmit Control register 2
	volatile uint16_t XCR1;		// Transmit Control register 1
	volatile uint16_t SRGR2;	// Sample rate generator register 2
	volatile uint16_t SRGR1;	// Sample rate generator register 1
	volatile uint16_t MCR2;		// Multi-channel register 2
	volatile uint16_t MCR1;		// Multi-channel register 1
	volatile uint16_t RCERA;	// Receive channel enable partition A
	volatile uint16_t RCERB;	// Receive channel enable partition B
	volatile uint16_t XCERA;	// Transmit channel enable partition A
	volatile uint16_t XCERB;	// Transmit channel enable partition B
	volatile uint16_t PCR;		// Pin Control register
	volatile uint16_t RCERC;	// Receive channel enable partition C
	volatile uint16_t RCERD;	// Receive channel enable partition D
	volatile uint16_t XCERC;	// Transmit channel enable partition C
	volatile uint16_t XCERD;	// Transmit channel enable partition D
	volatile uint16_t RCERE;	// Receive channel enable partition E
	volatile uint16_t RCERF;	// Receive channel enable partition F
	volatile uint16_t XCERE;	// Transmit channel enable partition E
	volatile uint16_t XCERF;	// Transmit channel enable partition F
	volatile uint16_t RCERG;	// Receive channel enable partition G
	volatile uint16_t RCERH;	// Receive channel enable partition H
	volatile uint16_t XCERG;	// Transmit channel enable partition G
	volatile uint16_t XCERH;	// Transmit channel enable partition H
	volatile uint16_t rsvd1[4];	// Reserved
	volatile uint16_t MFFINT;	// Interrupt enable
} MCBSP_Obj;

//! \brief Defines the Multichannel Buffered Serial Port (McBSP) handle
typedef struct _MCBSP_Obj_ *MCBSP_Handle;

extern MCBSP_Handle MCBSP_init(void *pMemory,const size_t numBytes);

extern void McBSP_stop(MCBSP_Handle handle);

extern void McBSP_run(MCBSP_Handle handle);

extern void MCBSP_resetTransmitter(MCBSP_Handle handle);

extern void MCBSP_resetReleaseTransmitter(MCBSP_Handle handle);

extern void MCBSP_resetReceiver(MCBSP_Handle handle);

extern void MCBSP_resetReleaseReceiver(MCBSP_Handle handle);

extern void MCBSP_resetSampleRateGenerator(MCBSP_Handle handle);

extern void MCBSP_resetFrameSynchronizationLogic(MCBSP_Handle handle);

extern void MCBSP_resetReleaseFrameSynchronizationLogic(MCBSP_Handle handle);

extern void MCBSP_resetReleaseSampleRateGenerator(MCBSP_Handle handle);

enum McBSP_Mode{
	McBsp_SPIMasterMode0, McBsp_SPIMasterMode1, McBsp_SPIMasterMode2, McBsp_SPIMasterMode3,
	McBsp_SPISlaveMode0,  McBsp_SPISlaveMode1,  McBsp_SPISlaveMode2,  McBsp_SPISlaveMode3
};

enum McBSP_Loopback{
	McBSP_disableLoopback, McBSP_enableLoopback
};

extern void MCBSP_setMode(MCBSP_Handle handle,
							uint16_t mode,
							uint16_t digitalLoopback);

enum McBSP_SampleRateGenSource{
	McBSP_SampleRateGen_Source_LSPCLK, McBSP_SampleRateGen_Source_MCLKR_Pin, McBSP_SampleRateGen_Source_MCLKX_Pin
};

extern void	MCBSP_sampleRateGeneratorInputClockMode(MCBSP_Handle handle, uint16_t sampleRateGenSRC);

enum MCBSP_TransmitFrameSyncMode{
	MCBSP_TransmitFrameSyncMode_EXTERNAL, 	// Sync is supplied by external source via the FSX Pin
	MCBSP_TransmitFrameSyncMode_INTERNAL	// Sync is supplied internal by by the Sample Rate Generator
};
extern void MCBSP_setTransmitFrameSynchronizationMode(MCBSP_Handle handle, uint16_t snycMode);

enum MCBSP_ReceiveFrameSyncMode{
	MCBSP_ReceiveFrameSyncMode_EXTERNAL,	// Sync is supplied by external source via the FSR Pin
	MCBSP_ReceiveFrameSyncMode_INTERNAL	    // Sync is supplied internal by by the Sample Rate Generator
};

extern void MCBSP_setReceiveFrameSynchronizationMode(MCBSP_Handle handle, uint16_t snycMode);

enum MCBSP_TransmitFrameSyncPol{
	MCBSP_TransmitFrameSync__ACTIVE_HIGH, MCBSP_TransmitFrameSync__ACTIVE_LOW
};

extern void MCBSP_setTransmitFrameSyncPolarity(MCBSP_Handle handle, uint16_t transmitPol);

enum MCBSP_ReceiveFrameSyncPol{
	MCBSP_ReceiveFrameSync__ACTIVE_HIGH, MCBSP_ReceiveFrameSync__ACTIVE_LOW
};

extern void MCBSP_setReceiveFrameSyncPolarity(MCBSP_Handle handle, uint16_t transmitPol);

extern void MCBSP_setSRGClockDivider(MCBSP_Handle handle, uint16_t divider);

enum MCBSP_TransmitDataDelay{
	MCBSP_TransmitDataDelay_0Bit, MCBSP_TransmitDataDelay_1Bit, MCBSP_TransmitDataDelay_2Bit
};

extern void MCBSP_setTransmitDataDelay(MCBSP_Handle handle, uint16_t delay);

enum MCBSP_ReceiveDataDelay{
	MCBSP_ReceiveDataDelay_0Bit, MCBSP_ReceiveDataDelay_1Bit, MCBSP_ReceiveDataDelay_2Bit
};

extern void MCBSP_setReceiveDataDelay(MCBSP_Handle handle, uint16_t delay);

enum MCBSP_ReceiveWordLength1{
	MCBSP_ReceiveWordLength1_8Bits, MCBSP_ReceiveWordLength1_12Bits, MCBSP_ReceiveWordLength1_16Bits,
	MCBSP_ReceiveWordLength1_20Bits, MCBSP_ReceiveWordLength1_24Bits, MCBSP_ReceiveWordLength1_32Bits
};

extern void MCBSP_setReceiveWordLength1(MCBSP_Handle handle, uint16_t length);

enum MCBSP_TransmitWordLength1{
	MCBSP_TransmitWordLength1_8Bits, MCBSP_TransmitWordLength1_12Bits, MCBSP_TransmitWordLength1_16Bits,
	MCBSP_TransmitWordLength1_20Bits, MCBSP_TransmitWordLength1_24Bits, MCBSP_TransmitWordLength1_32Bits
};

extern void MCBSP_setTransmitWordLength1(MCBSP_Handle handle, uint16_t length);

extern void MCBSP_InitDelayLoop(MCBSP_Handle handle, long systemFrequencyMHz);

enum MCBSP_TransmitClockPolarity{
	MCBSP_TransmitClockPolarity_dataSampleRisingEdge,
	MCBSP_TransmitClockPolarity_dataSampleFallingEdge
};

extern void MCBSP_setTransmitClockPolarity(MCBSP_Handle handle, uint16_t polarity);

enum MCBSP_TransmitClockMode{
	MCBSP_TransmitClockMode_ExternalClkSPISlave,
	MCBSP_TransmitClockMode_InternalClkSPIMaster
};

extern void MCBSP_setTransmitClockMode(MCBSP_Handle handle, uint16_t txClkMode);

enum MCBSP_ReceiveClockPolarity{
	MCBSP_ReceiveClockPolarity_dataSampleRisingEdge,
	MCBSP_ReceiveClockPolarity_dataSampleFallingEdge
};

extern void MCBSP_setReceiveClockPolarity(MCBSP_Handle handle, uint16_t polarity);

// this depends on the device being in DLB-Mode!
// these definitions are valid for non-DLB-Mode
enum MCBSP_ReceiveClockMode{
	MCBSP_ReceiveClockMode_ExternalClk,
	MCBSP_ReceiveClockMode_InternalClk
};

extern void MCBSP_setReceiveClockMode(MCBSP_Handle handle, uint16_t rcvClkMode);

enum MCBSP_ClockStopMode{
	MCBSP_ClockStopMode_DISABLED,
	MCBSP_ClockStopMode_WithoutClockDelay,
	MCBSP_ClockStopMode_HalfCycleClockDelay
};

extern void MCBSP_setClockStopMode(MCBSP_Handle handle, uint16_t clkStopMode);

#ifdef __cplusplus
}
#endif // extern "C"

#endif /* SPIMCBSP_H_ */
